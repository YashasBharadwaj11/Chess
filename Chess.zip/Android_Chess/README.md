# Android Chess game

[![Codacy Badge](https://app.codacy.com/project/badge/Grade/001f8eab562343cfb648f3779220790a)](https://www.codacy.com/gh/saadati944/Android_Chess/dashboard?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=saadati944/Android_Chess&amp;utm_campaign=Badge_Grade)

Chess game in android
written with java

Minimum sdk version : 24
Target sdk version : 29

![screenshot](./screenshot.png)

chess icons : [vecteezy.com](https://www.vecteezy.com/?utm_source=vecteezy-download&utm_medium=license-info-pdf&utm_campaign=license-info-document)
