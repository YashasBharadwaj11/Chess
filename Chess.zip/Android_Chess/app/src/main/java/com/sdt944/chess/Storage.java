package com.sdt944.chess;


/*
* Why I didn't use startActivityForResult() ???
* Because this one is easier ...
* */

public class Storage {
    public static Chessman.ChessmanType result = Chessman.ChessmanType.Pawn;
    public static Chess chess = null;
}